package com.capg.corejava.labbook.lab9;

import java.util.Scanner;

@FunctionalInterface
interface facto
{
	public int factorial(int n);
}
public class exercise5 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number:");int num = in.nextInt();
		
		facto f = (n)->
		{
			int fact=1;
			for(int i=1;i<=num;i++)
			{
				fact*=i;
			}
			return fact;	
		};
		System.out.println("The factorial of " +num+" is = "+f.factorial(num));
	}

}
