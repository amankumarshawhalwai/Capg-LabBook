package com.capg.corejava.labbook.lab9;

import java.util.Scanner;
@FunctionalInterface
interface str_manu
{
	public String format(String st);
}
public class exercise2 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the string:"); String st1 =in.nextLine();
		
		str_manu ins = (st)->
		{
			String str =" ";
			for(int i=0;i<st.length();i++)
			{
				str=str+" "+st.charAt(i);
			}
			return str;
		};
		System.out.println("The formatted string is = "+ins.format(st1));
	}

}
