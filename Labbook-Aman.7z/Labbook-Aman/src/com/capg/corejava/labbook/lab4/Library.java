package com.capg.corejava.labbook.lab4;


public class Library {

	public static void main(String[] args) {
		Book b = new Book(12345,"The malgudi days", 5, "RK Narayan"); 
		
		b.addItem(12345,"The malgudi days", 5);
		b.print();
		System.out.println("After check out number of copies left ");
		b.checkOut();
		b.print();
		System.out.println("After adding another one element  number of copies left ");
		b.addItem();
		b.print();
		Video v = new Video(1111, "The Merchant of venice", 3, 215, "Shakespeare", "drama", 2013);
		v.addItem(1111, "The Merchant of venice", 3);
		v.print();
		System.out.println("After check in number of copies left ");
		v.checkIn();
		v.print();
		
		

	}
}
