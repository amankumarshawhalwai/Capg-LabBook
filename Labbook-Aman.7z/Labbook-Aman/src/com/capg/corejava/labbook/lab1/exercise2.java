package com.capg.corejava.labbook.lab1;

import java.util.Scanner;
public class exercise2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String color;
		System.out.println("Enter the color:");
		color=sc.next();
		switch(color)
		{
		case "red":
			System.out.println("stop");
			break;
		case "yellow":
			System.out.println("ready");
			break;
		case "green":
			System.out.println("go");
			break;
		default:
			System.out.println("Enter correct color");
			
		}

	}

}
