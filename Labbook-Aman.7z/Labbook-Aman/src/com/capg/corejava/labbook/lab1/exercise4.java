package com.capg.corejava.labbook.lab1;
import java.util.Scanner;
public class exercise4 {
	void prime(int a,int b)
	{
		int i,j,f;
		for(i=a;i<b;i++)
		{
			f=0;
			for(j=2;j<=i/2;j++)
			{
				if(i%j==0) 
				{
					f++;
				    break;
			    }
		    }
			if(f==0)
				System.out.println(i);
	    }
    }

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int m,n;
		System.out.println("Enter starting range:");
		m=sc.nextInt();
		System.out.println("Enter ending range:");
		n=sc.nextInt();
		exercise4 ob = new exercise4();
		System.out.println("The prime numbers are:");
		ob.prime(m,n);
	}
}