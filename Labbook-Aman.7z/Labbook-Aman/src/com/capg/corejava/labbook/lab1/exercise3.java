package com.capg.corejava.labbook.lab1;

import java.util.Scanner;


public class exercise3 {
	void fibo(int n)
	{
		int i,a,b,c;
		a=1;b=1;c=0;
		System.out.println(a);
		System.out.println(b);
		for(i=1;i<=n;i++)
		{
			c=a+b;
			System.out.println(c);
			a=b;
			b=c;
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int num=sc.nextInt();
		exercise3 ob = new exercise3();
		ob.fibo(num);
		
	}

}