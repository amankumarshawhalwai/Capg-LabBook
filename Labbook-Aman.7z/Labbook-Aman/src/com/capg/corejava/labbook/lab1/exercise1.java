package com.capg.corejava.labbook.lab1;

import java.util.Scanner;

public class exercise1 {
	void cube(int num) 
	{
		int rem,num1;
		int sum=0;
		num1=num;
		while(num!=0)
		{
			rem=num%10;
			sum+=(rem*rem*rem);
			num/=10;
		}
		System.out.println("The sum of cube of "+num1+" is "+sum);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n;
		System.out.println("enter the number:");
		n=sc.nextInt();
		exercise1 ob= new exercise1();
		ob.cube(n);

	}

}