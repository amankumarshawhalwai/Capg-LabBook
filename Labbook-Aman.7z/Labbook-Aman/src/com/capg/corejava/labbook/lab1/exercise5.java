package com.capg.corejava.labbook.lab1;

import java.util.Scanner;


public class exercise5 {
	int calculateSum(int n)
	{
		int i,sum=0;
		for(i=1;i<=n;i++)
		{
			if(i%3==0 || i%5==0)
			{
				sum+=i;
			}
		}
		return sum;
	}
	

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the limit:");
		int lim=sc.nextInt();
		exercise5 ob = new exercise5();
		System.out.println("The sum is = "+ob.calculateSum(lim));
	}

}