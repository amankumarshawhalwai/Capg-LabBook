package com.capg.corejava.labbook.lab1;

import java.util.Scanner;
public class exercise8 {
	boolean checkNumber(int num)
	{
		while(num%2==0)
		{
			num/=2;
		}
		if(num==1)
			return true;
		else
			return false;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number to be checked:");
		int n = sc.nextInt();
		exercise8 ob = new exercise8();
		if(ob.checkNumber(n)==true)
			System.out.println(n+" is a power of 2");
		else
			System.out.println(n+" is not a power of 2");

	}

}