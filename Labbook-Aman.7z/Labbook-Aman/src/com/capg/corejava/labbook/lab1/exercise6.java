package com.capg.corejava.labbook.lab1;

import java.util.Scanner;
public class exercise6 {
	int calculateDifference(int n)
	{
		int i,Sum=0,sum1=0,sum2=0;
		for(i=1;i<=n;i++)
		{
			sum1+=(i*i);
			sum2+=i;
			Sum=(sum2*sum2)-sum1;
		}
		//System.out.println("Sum1 is = "+sum1);
		//System.out.println("Sum1 is = "+sum2);
		return Sum;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the limit:");
		int n=sc.nextInt();
		exercise6 ob = new exercise6();
		System.out.println("The Difference is = "+ob.calculateDifference(n));
	}

}