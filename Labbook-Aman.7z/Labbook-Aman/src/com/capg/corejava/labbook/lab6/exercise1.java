package com.capg.corejava.labbook.lab6;

import java.util.*;
import java.util.Map.Entry;

public class exercise1 {


	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner in  = new Scanner(System.in);
		Map<Integer,Integer> ma = new HashMap<>();
		System.out.println("Enter the number of terms:");
		int n = in.nextInt();
		while(n>0)
		{
			System.out.println("Enter the key value:");int id=in.nextInt();
			System.out.println("Enter the number:");int num=in.nextInt();
			ma.put(id, num);
			n--;
		}
		List<Map.Entry<Integer,Integer>> l = new ArrayList<>(ma.entrySet());
		l.forEach(System.out::println);
		Collections.sort(l,new Comparator<Map.Entry<Integer,Integer>>()
		{

			@Override
			public int compare(Entry<Integer, Integer> o1, Entry<Integer, Integer> o2) {
				// TODO Auto-generated method stub
				return o1.getValue()>o2.getValue()?1:-1;
			}
		});
		System.out.println("The sorted is:");
		l.forEach(System.out::println);
		
		
}
}

