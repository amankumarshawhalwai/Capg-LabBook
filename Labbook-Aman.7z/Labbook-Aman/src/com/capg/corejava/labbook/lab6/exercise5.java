package com.capg.corejava.labbook.lab6;

import java.util.Scanner;
import java.util.Collections;
import java.util.ArrayList;

public class exercise5 {
	
	public int getSecondSmallest(int []arr)
	{
		ArrayList<Integer> al = new ArrayList<>();
		for(Integer i:arr)
		{
			al.add(i);
		}
		Collections.sort(al);
		return al.get(1);
	}

	public static void main(String[] args) {
	  @SuppressWarnings("resource")
	Scanner in = new Scanner(System.in);
	  
	  System.out.println("Enter the number of elements in the array:");int n = in.nextInt();
	  int []arr1 = new int[n];
	  System.out.println("Enter the elements of the array:");
	  for(int i=0;i<n;i++)
	  {
		  arr1[i]=in.nextInt();
	  }
	  System.out.println("The second smallest element in the array is = "+new exercise5().getSecondSmallest(arr1));
	  
	}

}
