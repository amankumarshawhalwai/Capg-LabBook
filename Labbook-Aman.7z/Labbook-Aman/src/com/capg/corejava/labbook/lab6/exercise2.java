package com.capg.corejava.labbook.lab6;

import java.util.*;

public class exercise2 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner in = new  Scanner(System.in);
		Map<Character,Integer> hm = new HashMap<>();
		System.out.println("Enter the string:");
		String str = in.nextLine();
		
		for(int i = 0;i<str.length();i++)
		{
			if(hm.containsKey(str.charAt(i)))
			{
				int count  = hm.get(str.charAt(i));
				hm.put(str.charAt(i), ++count);
			}
			else
				hm.put(str.charAt(i), 1);
		}
		for(Map.Entry<Character, Integer> m: hm.entrySet())
		{
			System.out.println(m.getKey() +" = "+m.getValue());
		}
	}

}
