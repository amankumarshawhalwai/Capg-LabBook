package com.capg.corejava.labbook.lab6;

import java.util.Scanner;
import java.util.Map;
import java.util.HashMap;
public class exercise3 {

	public void getSquares(int []arr)
	{
		Map<Integer,Integer> h = new HashMap<>();
		for(int e:arr)
		{
			h.put(e, e*e);
		}
		System.out.println("**************************");
		for(Map.Entry<Integer,Integer> m:h.entrySet())
		{
			System.out.println(m.getKey()+"'s Square = "+m.getValue());
		}
	}
	
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter the number of elements:");
		int n = in.nextInt();
		int []ar = new int[n];
		System.out.println("Enter the elements:");
		for(int i=0;i<n;i++)
		{
			ar[i]=in.nextInt();
		}
		new exercise3().getSquares(ar);
	}
}
