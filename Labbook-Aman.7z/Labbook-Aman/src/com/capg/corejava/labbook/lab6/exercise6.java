package com.capg.corejava.labbook.lab6;

import java.util.*;
public class exercise6 {

		public static void main(String[] args) {
			@SuppressWarnings("resource")
			Scanner in  = new Scanner(System.in);
			Map<Integer,Integer> v = new HashMap<>();
			List<Integer> l = new ArrayList<>();
			System.out.println("Enter the number of data:");
			int n = in.nextInt();
			System.out.println("Enter the elements:");
		
			while(n>0)
			{
				System.out.println("Enter the id:");int id = in.nextInt();
				System.out.println("Enter the ages of the respective ids:");int age=in.nextInt();
				v.put(id, age);
				n--;
			}
			for(Map.Entry<Integer,Integer> m : v.entrySet())
			{
				if(m.getValue()>=18)
				{
				l.add(m.getKey());
				}
			}
			System.out.println("***************************************");
			System.out.println("The sorted eligible voters with id:");
			Collections.sort(l);
			l.forEach(System.out::println);
	}


	}


