package com.capg.corejava.labbook.lab6;

import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;
public class exercise4 {

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		Map<Integer,Double> hm1 = new HashMap<>();//declaration of first hashmap
		Map<Integer,String> hm2 = new HashMap<>(); //declaration of second hashmap
		String grade="";
		System.out.println("Enter the number of elements:");
		int n = in.nextInt();
		while(n>0)//user defined hashMap input
		{
			System.out.println("Enter the ID:");int id=in.nextInt();
			System.out.println("Enter the marks");double mark = in.nextDouble();
			hm1.put(id, mark);//inserting elements into hashMap
			n--;
		}
		for(Map.Entry<Integer, Double> m: hm1.entrySet())
			//condition checking logic
		{
			if(m.getValue()>=90)
				grade="GOLD";
			else if(m.getValue()>=80 && m.getValue()<90)
				grade="SILVER";
			else if(m.getValue()>=70 && m.getValue()<80)
				grade="BRONZE";
			else
				grade="BETTER LUCK NEXT TIME";
			
			hm2.put(m.getKey(), grade);//inserting new values into second hashMap
		}
		System.out.println("************************************");
		System.out.println("Rollno.\tMedal");
		for(Map.Entry<Integer, String> o: hm2.entrySet())
		{
			System.out.println(" "+o.getKey()+"    = "+o.getValue());
		}

	}

}
