package com.capg.corejava.labbook.lab6;
import java.util.*;
public class exercise7 {
	
	public void sortAll(int []arr)
	{
		ArrayList<Integer> inp = new ArrayList<>();
		ArrayList<Integer> out = new ArrayList<>();
		
		for(int e:arr)
		{
			inp.add(e);
		}
		for(int e:inp)
		{
			StringBuffer s = new StringBuffer(String.valueOf(e));
			//s.reverse();e=Integer.parseInt(String.valueOf(s));
			out.add(Integer.parseInt(String.valueOf(s.reverse())));
		}
		Collections.sort(out);
		System.out.println("The reversed and sorted list is:");
		out.forEach(System.out::println);
	}

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter the number of elements:");
		int n = in.nextInt();
		int []arr = new int[n];
		System.out.println("Enter the elements:");
		for(int i = 0;i<n;i++)
		{
			arr[i] = in.nextInt();
		}
		new exercise7().sortAll(arr);
	}

}
