package com.capg.corejava.labbook.lab3;
import java.util.Scanner;
public class exercise2 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the string:");
		String str=in.next();
		StringBuffer str2 = new StringBuffer();//StringBuilder str2 = new StringBuilder();
		str2.append(str);
		System.out.println("The mirror image of "+str+" is:");
		System.out.println(str+'|'+str2.reverse());

	}

}
