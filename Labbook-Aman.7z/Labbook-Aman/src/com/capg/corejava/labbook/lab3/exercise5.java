package com.capg.corejava.labbook.lab3;
import java.util.Scanner;
public class exercise5 {

	public static void main(String[] args) {
		Scanner in  = new Scanner(System.in);
		String st = new String();
		System.out.println("Enter the string:");
		st=in.next();
		int lines=0,words=0,chars=0;
		for(int i=0;i<st.length();i++)
		{
			char ch=st.charAt(i);
			int code=(int)ch;
			if(code!=10)
				chars++;
				if(code==32)
				words++;
				if(code==13)
				{
					lines++;
					words++;
				}
			}
			System.out.println("No.of characters = "+chars);
			System.out.println("No.of words = "+(words+1));
			System.out.println("No.of lines = "+(lines+1));
			                 
     }
     

}
