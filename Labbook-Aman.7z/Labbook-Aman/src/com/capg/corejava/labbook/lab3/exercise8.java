package com.capg.corejava.labbook.lab3;
import java.util.*;
public class exercise8 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String st;
		System.out.println("Enter the string:");
		st=in.next();
		for(int i=0;i<st.length()-1;i++)
		{
			char ch=st.charAt(i);
			//System.out.println((int)st.charAt(i));
			if((int)st.charAt(i+1)>(int)st.charAt(i))
			{
				System.out.println("Positive");
			}
			else
			{
				System.out.println("Not Positive");
			}
				
		}
	}

}
