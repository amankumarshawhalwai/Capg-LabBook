package com.capg.corejava.labbook.lab3;
import java.util.Scanner;
public class exercise3 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String st = new String();
		String word="";
		System.out.println("Enter the string:");
		st=in.next();
		for(int i=0;i<st.length();i++)
		{
			char ch=st.charAt(i);
			if(ch!='A'&&ch!='I'&&ch!='E'&&ch!='O'&&ch!='U'&&ch!='a'&&ch!='i'&&ch!='e'&&ch!='o'&&ch!='u')
				word=word+(char)(((int)ch)+1);
				
			else
				word+=ch;
		}
		
		System.out.println("The new String is= "+word);

	}

}
