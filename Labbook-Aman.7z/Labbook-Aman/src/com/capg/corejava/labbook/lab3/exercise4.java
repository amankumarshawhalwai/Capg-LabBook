package com.capg.corejava.labbook.lab3;
import java.util.Scanner;
public class exercise4 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String st="",k="";
		int diff=0;
		System.out.println("Enter the number:");
		int num=in.nextInt();
		st=Integer.toString(num);
		for(int i=0;i<st.length()-1;i++)
		{
			diff=(Character.getNumericValue(st.charAt(i)))-(Character.getNumericValue(st.charAt(i+1)));
			//System.out.println(Math.abs(diff));
			k+=Integer.toString(Math.abs(diff));
			//System.out.println(k);
		}
		System.out.println("-----------");
		System.out.println("The newly generated number is:"+k);
		
	}

}
