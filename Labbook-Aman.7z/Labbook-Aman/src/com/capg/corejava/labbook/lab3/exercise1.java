package com.capg.corejava.labbook.lab3;
import java.util.Scanner;
public class exercise1 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number:");
		int n=in.nextInt();
		System.out.println("-------------");
		int temp=n;
		int sum=0;
		String st=Integer.toString(temp);
		for(int i=0;i<st.length();i++)
		{
			System.out.println("The digit at "+i+"th position is= "+st.charAt(i));
		}
		while(temp!=0)
			{
			int rem=temp%10;
			sum+=rem;
			temp/=10;
			}
		System.out.println("-------------");
		System.out.println("The sum of the digits of "+n+" is= "+sum);
	}}