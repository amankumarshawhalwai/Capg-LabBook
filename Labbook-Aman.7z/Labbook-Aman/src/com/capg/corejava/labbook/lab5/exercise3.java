package com.capg.corejava.labbook.lab5;

import java.util.Scanner;

class EmployeeException extends Exception
{
	public  EmployeeException()
	{
		System.out.println("Your salary is less than 3000");
	}
}
public class exercise3 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the salary of the employee:");
		int sal=in.nextInt();
		 
		try
		{
			if(sal<3000)
				throw new EmployeeException();
			else
				System.out.println("Your salary is OK");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		finally
		{
			System.out.println("---------------------------");
			System.out.println("Salary baseline is 3000");
			System.out.println("If less than 3000 then better luck next time");
		}
	}

}
