package com.capg.corejava.labbook.lab5;
import java.util.Scanner;

 class FirstnameException extends Exception
 {
	 public FirstnameException()
	 {
		 System.out.println("Your first name is invalid");
	 }
 }
 class LastnameException extends Exception
 {
	 public LastnameException()
	 {
		 System.out.println("Your last name is invalid");
	 }
 }
public class exercise2 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String f_name="",l_name="";
		System.out.println("Enter your firstname:");
		f_name=in.nextLine();
		System.out.println("Enter your lastname:");
		l_name=in.nextLine();
		
		try {
			if(f_name=="")
				throw new FirstnameException();
			else
				System.out.println("Your first name is ok");
		}
		catch(FirstnameException a)
		{
			System.out.println(a);
		}
		
		try {
			if(l_name=="")
				throw new LastnameException();
			else
				System.out.println("Your last name is ok");
		}
		catch(LastnameException a)
		{
			System.out.println(a);
		}
		finally
		{
			System.out.println("Your name is: "+f_name+" "+l_name);
		}

	}

}
