package com.capg.corejava.labbook.lab5;
import java.util.Scanner;

class AgeException extends Exception
   { 
	public AgeException()
	{
	  System.out.println("Age is Invalid");
   }
  }
public class exercise1 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter your age:");
		int age=in.nextInt();
		
		try {
			if(age<15)
				throw new AgeException();
			else
				System.out.println("Age is ok");
		}
		catch(AgeException a){
			System.out.println(a);
		}
		finally {
			System.out.println("------------------------");
			System.out.println("The valid age is 15");
			System.out.println("Your age is: "+age);
		}

	}

}
