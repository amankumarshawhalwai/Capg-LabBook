

//There is some logical error in the code. Correct that before launching for output

package com.capg.corejava.labbook.lab2;
import java.util.Scanner;
public class exercise2 {
	public String sortStrings(String str[],int n)
	{
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				if(str[i].compareTo(str[j])>0)
				{
					String temp=str[i];
					str[i]=str[j];
					str[j]=temp;
				}
			}
		}
		
		if(n%2==0)
		{
			for(int i=0;i<n/2;i++)
			{
				str[i]=str[i].toUpperCase();
			}
		}
		else
		{
			for(int i=0;i<(n/2)+1;i++)
			{
				str[i]=str[i].toUpperCase();
			}
		}
		return str[n];
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String str[] = new String[20];
		System.out.println("Enter the number of strings:");
		int n=in.nextInt();
		
		System.out.println("Enter the strings:");
		for(int i=0;i<n;i++)
		{
			str[i]=in.next();
		}
		exercise2 ob = new exercise2();
		System.out.println("*************************");
		System.out.println("The desired array is");
		for(int i=0;i<n;i++)
		{
			System.out.print(ob.sortStrings(str,n));
		}
	}

}
