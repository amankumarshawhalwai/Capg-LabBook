package com.capg.corejava.labbook.lab2;
import java.util.*;
public class exercise3 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int i,j;
		String b="",st;
		int arr[] = new int[10];
		System.out.println("Enter the number of elements:");
		int n=in.nextInt();
		System.out.println("Enter the elements:");
		for(i=0;i<n;i++)
		{
			arr[i]=in.nextInt();
		}
		for(i=0;i<n;i++)
		{
			b=Integer.toString(arr[i]);
			//System.out.println(b);
			st="";
			for(j=b.length()-1;j>=0;j--)
			{
				st+=b.charAt(j);
			}
		    arr[i]=Integer.parseInt(st);
		}
		for(i=0;i<n;i++)
		{
		  for(j=i+1;j<n;j++)
		{
			if(arr[i]>arr[j])
			{
				int temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
	}
		System.out.println("*********************************");
		System.out.print("The Sorted array is:");
		for(i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
}}
